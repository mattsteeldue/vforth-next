\ 07-01b.f -- the Forth side of a NextBASIC listing
\ BASIC: bas2f/txt/07-01.txt
\ guide: doc/basic-to-vforth/07-strings.md
\ written by util/guide-forth.py: edit the guide, not this file
\
\   10 LET a$="Spectrum"
\   20 FOR n=1 TO LEN a$
\   30   PRINT a$( TO n)
\   40 NEXT n

\ --- libraries the guide loads elsewhere
NEEDS /STRING

\ --- words defined earlier in the guide

\ 07-strings.md:26
NEEDS S"
: PLANET  ( -- a n )  S" Spectrum" ;
PLANET TYPE                     \ => Spectrum
PLANET NIP .                    \ => 8

\ --- the translation

\ 07-strings.md:309
: TAILS  ( a n -- )
    BEGIN  DUP WHILE
        CR 2DUP TYPE  1 /STRING
    REPEAT  2DROP ;
PLANET TAILS
\ output of the last line:
\ Spectrum
\ pectrum
\ ectrum
\ ctrum
\ trum
\ rum
\ um
\ m
